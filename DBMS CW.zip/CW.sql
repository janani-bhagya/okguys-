CREATE DATABASE Amaa_Hospital;
USE Amaa_Hospital;

CREATE TABLE Employee (
    EmpID VARCHAR(10) PRIMARY KEY,
    Fname VARCHAR(50) NOT NULL,
    Lname VARCHAR(50),
    Gender VARCHAR(10) NOT NULL,
    DOB DATE CHECK (DOB<='2000-01-31'),
    Address VARCHAR(50),
    PhoneNo VARCHAR(10),
    Email VARCHAR(100),
    Salary DECIMAL(10, 2)
);

INSERT INTO Employee VALUES
    ('E001', 'John', 'Doe', 'Male', '1990-05-15', 'Kurunagala', '0764621348', 'johndoe@email.com', 50000.00),
    ('E002', 'Jane', 'Smith', 'Female', '1992-08-21', 'Anuradhapura', '0714567893', 'janesmith@email.com', 55000.00),
    ('E003', 'Michael', 'Johnson', 'Male', '1985-11-10', 'Kagalle', '0753217941', 'michaeljohnson@email.com', 60000.00),
    ('E004', 'Emily', 'Brown', 'Female', '1988-03-25', 'Colombo', '0727894563', 'emilybrown@email.com', 52000.00),
    ('E005', 'Ana', 'Davis', 'Female', '1993-07-17', 'Kandy', '0717896541', 'Anadavis@email.com', 48000.00),
    ('E006', 'Sarah', 'Wilson', 'Female', '1991-12-10', 'Matara', '0764626348', 'sarahwilson@email.com', 51000.00),
    ('E007', 'Robert', 'Taylor', 'Male', '1989-09-05', 'Anuradhapura', '0714589893', 'roberttaylor@email.com', 58000.00),
    ('E008', 'Jessica', 'Martinez', 'Female', '1994-04-20', 'Colombo', '0753327941', 'jessicamartinez@email.com', 49000.00),
    ('E009', 'William', 'Anderson', 'Male', '1987-06-30', 'Kandy', '0727873663', 'williamanderson@email.com', 53000.00),
    ('E010', 'Amanda', 'Thomas', 'Female', '1990-02-15', 'Colombo', '0717168541', 'amandathomas@email.com', 57000.00),
    ('E011', 'Mark', 'Wilson', 'Male', '1992-11-18', 'Galle', '0764621538', 'markwilson@email.com', 54000.00),
    ('E012', 'Sophia', 'Brown', 'Female', '1986-08-27', 'Kurunegala', '0714567821', 'sophiabrown@email.com', 62000.00),
    ('E013', 'David', 'Garcia', 'Male', '1984-05-14', 'Colombo', '0753217554', 'davidgarcia@email.com', 48000.00),
    ('E014', 'Emma', 'Lopez', 'Female', '1993-03-30', 'Anuradhapura', '0727894352', 'emmalopez@email.com', 51000.00),
    ('E015', 'Daniel', 'Harris', 'Male', '1990-09-05', 'Kandy', '0717896554', 'danielharris@email.com', 56000.00),
    ('E016', 'Olivia', 'Clark', 'Female', '1988-12-17', 'Colombo', '0764626652', 'oliviaclark@email.com', 59000.00),
    ('E017', 'James', 'Young', 'Male', '1985-06-20', 'Matara', '0714589875', 'jamesyoung@email.com', 52000.00),
    ('E018', 'Isabella', 'Lewis', 'Female', '1994-02-10', 'Anuradhapura', '0753327234', 'isabellalewis@email.com', 58000.00),
    ('E019', 'Alexander', 'Lee', 'Male', '1987-11-25', 'Colombo', '0727873987', 'alexanderlee@email.com', 54000.00),
    ('E020', 'Mia', 'King', 'Female', '1991-04-14', 'Kandy', '0717168523', 'miaking@email.com', 61000.00);

	SELECT * FROM Employee; 

CREATE TABLE Doctor (
    EmpID VARCHAR(10) PRIMARY KEY  NOT NULL,
    LicenceNumber VARCHAR(50),
    Specialization VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

INSERT INTO Doctor VALUES
    ('E001', 'LC12345', 'Cardiology'),
    ('E003', 'LC54321', 'Pediatrics'),
    ('E006', 'LC98765', 'Orthopedics'),
    ('E007', 'LC45678', 'Neurology'),
    ('E009', 'LC87654', 'Oncology'),
    ('E011', 'LC23456', 'Dermatology'),
    ('E013', 'LC65432', 'Gastroenterology'),
    ('E015', 'LC34567', 'Ophthalmology'),
    ('E017', 'LC76543', 'Psychiatry');

	SELECT * FROM Doctor; 

CREATE TABLE Receptionist (
    EmpID VARCHAR(10) PRIMARY KEY,
    Shift VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

INSERT INTO Receptionist VALUES
    ('E002', 'Morning'),
    ('E004', 'Evening'),
    ('E008', 'Night'),
    ('E010', 'Morning'),
    ('E012', 'Evening');

	SELECT * FROM Receptionist; 

CREATE TABLE Nurse (
    EmpID VARCHAR(10) PRIMARY KEY,
    Shift VARCHAR(50),
    CertificateLevel VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

INSERT INTO Nurse VALUES
    ('E005', 'Night', 'Registered Nurse'),
    ('E014', 'Day', 'Certified Nurse'),
    ('E016', 'Night', 'Licensed Practical Nurse'),
    ('E018', 'Night', 'Registered Nurse'),
    ('E019', 'Day', 'Certified Nurse'),
	('E020', 'Day', 'Licensed Practical Nurse');

	SELECT * FROM Nurse; 

CREATE TABLE LanguageSkill (
    EmpID VARCHAR(10),
    Language VARCHAR(50),
    PRIMARY KEY (EmpID, Language),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

INSERT INTO LanguageSkill VALUES
    ('E002', 'Tamil'),
	('E002', 'Sinhala'),
	('E002', 'English'),
	('E004', 'Tamil'),
	('E004', 'Sinhala'),
	('E008', 'English'),
	('E010', 'Tamil'),
	('E010', 'English'),
	('E012', 'English'),
	('E012', 'Tamil');

	SELECT * FROM LanguageSkill; 

CREATE TABLE Trainee (
    EmpID VARCHAR(10) PRIMARY KEY,
    TrainingStartDate DATE,
    TrainingEndDate DATE,
    FOREIGN KEY (EmpID) REFERENCES Doctor(EmpID)
);

INSERT INTO Trainee (EmpID, TrainingStartDate) VALUES
	('E001', '2019-10-30'),
	('E007', '2020-01-28'),
	('E013', '2020-03-15');

	SELECT * FROM Trainee; 

CREATE TABLE Permanent (
    EmpID VARCHAR(10) PRIMARY KEY,
    Benefits VARCHAR(255),
    Schedule VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Doctor(EmpID)
);

INSERT INTO Permanent VALUES
	('E003', 'Health insurance, Dental insurance', 'Monday-Friday'),
	('E006', 'Retirement plan, Paid time off', 'Weekends'),
	('E011', 'Health insurance, Dental insurance', 'Monday-Friday'),
	('E017', 'Dental insurance, Paid time off', 'Monday-Friday');

	SELECT * FROM Permanent; 

CREATE TABLE Visiting (
    EmpID VARCHAR(10) PRIMARY KEY,
    VisitDuration VARCHAR(50),
    Schedule VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Doctor(EmpID)
);

INSERT INTO Visiting VALUES
	('E009', 'Bi-weekly', 'Morning'),
	('E015', 'Daily', 'Evening');

	SELECT * FROM Visiting; 

CREATE TABLE Ward (
    WardNo VARCHAR(10) PRIMARY KEY,
    WardName VARCHAR(50),
    Type VARCHAR(50),
    Capacity INT,
    Availability VARCHAR(10)
);

INSERT INTO Ward VALUES
    ('W01', 'General Ward', 'General', 20, 'Available'),
    ('W02', 'ICU', 'Intensive Care Unit', 30, 'Full'),
    ('W03', 'Pediatric Ward', 'Pediatric', 15, 'Available'),
    ('W04', 'Surgical Ward', 'Surgical', 15, 'Available'),
    ('W05', 'Maternity Ward', 'Maternity', 12,'Available'),
    ('W06', 'Psychiatric Ward', 'Psychiatric', 10, 'Available'),
    ('W07', 'Emergency Ward', 'Emergency', 25, 'Full'),
    ('W08', 'Oncology Ward', 'Oncology', 10, 'Available'),
    ('W09', 'Orthopedic Ward', 'Orthopedic', 25, 'Full'),
    ('W10', 'Neurology Ward', 'Neurology', 30, 'Full');

	SELECT * FROM Ward; 

CREATE TABLE EmployeeWard (
    EmpID VARCHAR(10),
    WardNo VARCHAR(10),
    PRIMARY KEY (EmpID, WardNo),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (WardNo) REFERENCES Ward(WardNo)
);

INSERT INTO EmployeeWard VALUES
    ('E001', 'W01'),
    ('E003', 'W02'),
    ('E005', 'W01'),
    ('E007', 'W03'),
    ('E009', 'W04'),
    ('E005', 'W05'),
    ('E015', 'W06'),
    ('E006', 'W07'),
    ('E016', 'W08'),
    ('E009', 'W09'),
	('E011', 'W10'),
    ('E013', 'W02'),
    ('E015', 'W01'),
    ('E017', 'W03'),
    ('E019', 'W04'),
    ('E018', 'W05'),
    ('E014', 'W06'),
    ('E016', 'W07'),
    ('E017', 'W08'),
    ('E010', 'W09'),
	('E019', 'W01'),
    ('E014', 'W02'),
    ('E005', 'W10'),
    ('E014', 'W03'),
    ('E011', 'W04'),
    ('E020', 'W09');

	SELECT * FROM EmployeeWard; 

CREATE TABLE Patients (
    PatID VARCHAR(10) PRIMARY KEY  NOT NULL,
    Fname VARCHAR(50) NOT NULL,
    Lname VARCHAR(50),
    Gender VARCHAR(10) NOT NULL,
    Address VARCHAR(50) NOT NULL,
    PhoneNo VARCHAR(10),
    AdmittedDate DATE,
    DischargeDate DATE,
    WardNo VARCHAR(10),
    FOREIGN KEY (WardNo) REFERENCES Ward(WardNo)
);

INSERT INTO Patients VALUES
    ('P001', 'Alice', 'Smith', 'Female', 'Kurunagala', '0764983217', '2023-01-15', '2023-01-30', 'W01'),
    ('P002', 'Bob', 'Johnson', 'Male', 'Anuradhapura', '0758934891', '2023-02-01', NULL, 'W02'),
    ('P003', 'Carol', 'Williams', 'Male', 'Colombo', '0723674920', '2023-02-10', NULL, 'W03'),
    ('P004', 'David', 'Jones', 'Male', 'Kandy', '0713496740', '2023-02-20', NULL, 'W04'),
    ('P005', 'Eva', 'Brown', 'Female', 'Galle', '0701569874', '2023-03-05', '2023-11-16', 'W05'),
    ('P006', 'Frank', 'Davis', 'Male', 'Matara', '0764983218', '2023-03-15', NULL, 'W01'),
    ('P007', 'Grace', 'Martinez', 'Female', 'Kurunegala', '0758934892', '2023-04-01', NULL, 'W02'),
    ('P008', 'Henry', 'Taylor', 'Male', 'Anuradhapura', '0723674921', '2023-04-10', NULL, 'W03'),
    ('P009', 'Ivy', 'Clark', 'Female', 'Colombo', '0713496741', '2023-05-01', NULL, 'W04'),
    ('P010', 'Jack', 'Lewis', 'Male', 'Kandy', '0701569875', '2023-05-20', NULL, 'W05'),
    ('P011', 'Kelly', 'Garcia', 'Female', 'Galle', '0764983219', '2023-06-05', '2023-08-30', 'W01'),
    ('P012', 'Liam', 'Lee', 'Male', 'Matara', '0758934893', '2023-06-15', NULL, 'W02'),
    ('P013', 'Mary', 'Harris', 'Female', 'Kurunegala', '0723674922', '2023-07-01', NULL, 'W03'),
    ('P014', 'Nancy', 'Young', 'Female', 'Anuradhapura', '0713496742', '2023-07-10', NULL, 'W04'),
    ('P015', 'Oscar', 'King', 'Male', 'Colombo', '0701569876', '2023-08-01', NULL, 'W05');

	SELECT * FROM Patients; 

CREATE TABLE Invoice (
    InvoiceNo INT PRIMARY KEY,
    TotalAmount DECIMAL(10, 2),
    Date DATE,
    PatID VARCHAR(10),
    FOREIGN KEY (PatID) REFERENCES Patients(PatID)
);

INSERT INTO Invoice VALUES
    (1001, 1500.00, '2023-01-20', 'P001'),
    (1002, 2000.00, '2023-02-05', 'P003'),
    (1003, 1800.00, '2023-02-12', 'P006'),
    (1004, 2200.00, '2023-02-25', 'P008'),
    (1005, 1700.00, '2023-03-10', 'P010'),
    (1006, 1900.00, '2023-03-15', 'P005'),
    (1007, 2100.00, '2023-03-25', 'P009'),
    (1008, 1600.00, '2023-04-05', 'P002'),
    (1009, 2300.00, '2023-04-12', 'P004'),
    (1010, 2000.00, '2023-04-25', 'P007');

	SELECT * FROM Invoice; 

CREATE TABLE Payment (
    InvoiceNo INT,
    PaymentDate DATE,
    Method VARCHAR(50),
    PRIMARY KEY (InvoiceNo),
    FOREIGN KEY (InvoiceNo) REFERENCES Invoice(InvoiceNo)
);

INSERT INTO Payment VALUES
    (1001, '2023-01-25', 'Credit Card'),
    (1002, '2023-02-10', 'Cash'),
    (1003, '2023-02-15', 'Debit Card'),
    (1004, '2023-03-01', 'Cash'),
    (1005, '2023-03-20', 'Credit Card'),
    (1006, '2023-03-30', 'Cash'),
    (1007, '2023-04-05', 'Debit Card'),
    (1008, '2023-04-15', 'Cash'),
    (1009, '2023-04-20', 'Credit Card'),
    (1010, '2023-04-30', 'Debit Card');

	SELECT * FROM Payment; 

CREATE TABLE Treatment (
    TreatmentID VARCHAR(10) PRIMARY KEY,
    TreatmentName VARCHAR(255),
    Date DATE,
    Status VARCHAR(50),
    Description VARCHAR(255),
    PatID VARCHAR(10),
    DocID VARCHAR(10),
	NrsID VARCHAR(10),
    FOREIGN KEY (PatID) REFERENCES Patients(PatID),
    FOREIGN KEY (DocID) REFERENCES Doctor(EmpID),
	FOREIGN KEY (NrsID) REFERENCES Nurse(EmpID)
);

INSERT INTO Treatment VALUES
    ('T01', 'Physical Therapy', '2023-01-22', 'Ongoing', 'Physical therapy sessions for rehabilitation.', 'P001', 'E003','E005'),
    ('T02', 'Cardiac Monitoring', '2023-02-03', 'Scheduled', 'Regular cardiac monitoring.', 'P011', 'E009','E014'),
    ('T03', 'Orthopedic Surgery', '2023-02-15', 'Ongoing', 'Surgery for knee replacement.', 'P005', 'E017','E016'),
    ('T04', 'Neurological Examination', '2023-03-01', 'Scheduled', 'Detailed neurological examination.', 'P009', 'E006','E020'),
    ('T05', 'Chemotherapy', '2023-03-20', 'Ongoing', 'Chemotherapy treatment for cancer.', 'P013', 'E011','E018');

	SELECT * FROM Treatment; 

CREATE TABLE Prescription (
    PrescriptionID INT PRIMARY KEY,
    Instructions VARCHAR(255),
    Date DATE,
    Status VARCHAR(50),
    Description VARCHAR(255),
    PatID VARCHAR(10),
    EmpID VARCHAR(10),
    FOREIGN KEY (PatID) REFERENCES Patients(PatID),
    FOREIGN KEY (EmpID) REFERENCES Doctor(EmpID)
);

INSERT INTO Prescription VALUES
	(1, 'Take one tablet daily after meals.', '2024-02-25', 'Active', 'Pain management', 'P001', 'E003'),
	(2, 'Apply cream twice daily to affected area.', '2024-02-24', 'Active', 'Skin irritation treatment', 'P011', 'E009'),
	(3, 'Take two capsules every 12 hours.', '2024-02-23', 'Active', 'Antibiotic regimen', 'P005', 'E017'),
	(4, 'Take one tablet daily with food.', '2024-02-22', 'Active', 'Vitamin supplement', 'P009', 'E006'),
	(5, 'Take as needed for pain relief.', '2024-02-21', 'Active', 'Analgesic medication', 'P013', 'E011');

	SELECT * FROM Prescription; 

CREATE TABLE Medicine (
    MedicineCode INT PRIMARY KEY,
    Name VARCHAR(255),
    Manufacture VARCHAR(255)
);

INSERT INTO Medicine VALUES
    (101, 'Aspirin', 'ABC Pharmaceuticals'),
    (102, 'Amoxicillin', 'XYZ Pharmaceuticals'),
    (103, 'Insulin', 'PQR Pharmaceuticals'),
    (104, 'Paracetamol', 'DEF Pharmaceuticals'),
    (105, 'Lisinopril', 'GHI Pharmaceuticals'),
    (106, 'Metformin', 'JKL Pharmaceuticals'),
    (107, 'Atorvastatin', 'MNO Pharmaceuticals'),
    (108, 'Omeprazole', 'STU Pharmaceuticals'),
    (109, 'Warfarin', 'VWX Pharmaceuticals'),
    (110, 'Simvastatin', 'YZA Pharmaceuticals');

	SELECT * FROM Medicine; 

CREATE TABLE PrescriptionMedicine (
    PrescriptionID INT,
    MedicineCode INT,
    Dosage VARCHAR(50),
    PRIMARY KEY (PrescriptionID, MedicineCode),
    FOREIGN KEY (PrescriptionID) REFERENCES Prescription(PrescriptionID),
    FOREIGN KEY (MedicineCode) REFERENCES Medicine(MedicineCode)
);

INSERT INTO PrescriptionMedicine VALUES
    (1, 101, 'Take one tablet daily'),
    (2, 102, 'Take two tablets twice a day'),
    (3, 103, 'Inject 10 units subcutaneously once a day'),
    (4, 104, 'Take one tablet every 4-6 hours as needed for pain'),
    (5, 105, 'Take one tablet daily'),
    (1, 106, 'Take one tablet twice daily'),
    (2, 107, 'Take one tablet daily'),
    (3, 108, 'Take one tablet before breakfast'),
    (4, 109, 'Take one tablet at bedtime'),
    (5, 110, 'Take one tablet daily');
	
	SELECT * FROM PrescriptionMedicine;

CREATE TABLE MedicineTreatment (
    MedicineCode INT,
    TreatmentID VARCHAR(10),
    PRIMARY KEY (MedicineCode, TreatmentID),
    FOREIGN KEY (MedicineCode) REFERENCES Medicine(MedicineCode),
    FOREIGN KEY (TreatmentID) REFERENCES Treatment(TreatmentID)
);

INSERT INTO MedicineTreatment VALUES
    (101, 'T01'),
    (102, 'T05'),
    (103, 'T01'),
    (104, 'T04'),
    (105, 'T02'),
    (106, 'T03'),
    (107, 'T02'),
    (108, 'T05'),
    (109, 'T02'),
    (110, 'T03');

SELECT * FROM MedicineTreatment; 

SELECT EmpID,Fname,Lname,Address,Salary FROM Employee WHERE Salary > 50000;

--AND_Oparator
SELECT * FROM Employee WHERE Salary >= 50000 AND salary <= 55000;

--BETWEEN_Oparator
SELECT * FROM Ward WHERE Capacity BETWEEN 10 AND 20;
SELECT * FROM Employee WHERE Salary NOT BETWEEN 50000 AND 65000;

--OR_Oparator
SELECT * FROM Patients  WHERE Address = 'Kandy' OR AdmittedDate > '2023-05-01';

--IN_Oparator
SELECT WardNO,WardName,Capacity,Availability FROM Ward WHERE WardName IN ('General Ward','ICU','Emergency Ward');
SELECT * FROM LanguageSkill WHERE Language NOT IN ('English');

--IS_NULL_Oparator
SELECT * FROM Patients WHERE DischargeDate IS NULL;
SELECT * FROM Patients WHERE DischargeDate IS NOT NULL;

--Like_Oparator
SELECT * FROM Employee WHERE Fname LIKE 'J%';
SELECT * FROM Employee WHERE Lname LIKE '%e';
SELECT * FROM Patients WHERE Fname LIKE '%o%';
SELECT * FROM Patients WHERE Fname LIKE '____';

--CHANGE_ORDER
SELECT * FROM Employee ORDER BY Salary;
SELECT * FROM Patients ORDER BY AdmittedDate DESC;

--FUNCTIONS
SELECT COUNT(EmpID) AS 'Trainee Count' FROM Trainee;
SELECT SUM(Salary) AS 'All Salary' FROM Employee;
SELECT AVG(Capacity) AS 'Avg Capacity' FROM Ward;
SELECT MIN(Salary) AS 'Min Salary' FROM Employee;
SELECT MAX(Salary) AS 'Max Salary' FROM Employee;

--GROUP_BY
SELECT EmpID, SUM(Salary) AS 'SUM' FROM Employee GROUP BY EmpID HAVING SUM(Salary) < 50000;

--DELETE_ROW
DELETE FROM Trainee WHERE EmpID = 'E001';
DELETE FROM Employee WHERE EmpID = 'E001';

--UPDATE_RECOARD
UPDATE Employee SET Fname = 'Amal', Salary = 55000.00 WHERE EmpID = 'E001';

--ALTER_TABLE
ALTER TABLE Employee ADD Experience int;

UPDATE Employee SET Experience = 1 WHERE EmpID = 'E001';
UPDATE Employee SET Experience = 5 WHERE EmpID = 'E002';
UPDATE Employee SET Experience = 10 WHERE EmpID = 'E003';
UPDATE Employee SET Experience = 3 WHERE EmpID = 'E004';
UPDATE Employee SET Experience = 4 WHERE EmpID = 'E005';
UPDATE Employee SET Experience = 7 WHERE EmpID = 'E006';
UPDATE Employee SET Experience = 2 WHERE EmpID = 'E007';
UPDATE Employee SET Experience = 6 WHERE EmpID = 'E008';
UPDATE Employee SET Experience = 1 WHERE EmpID = 'E009';
UPDATE Employee SET Experience = 2 WHERE EmpID = 'E010';
UPDATE Employee SET Experience = 7 WHERE EmpID = 'E011';
UPDATE Employee SET Experience = 6 WHERE EmpID = 'E012';
UPDATE Employee SET Experience = 3 WHERE EmpID = 'E013';
UPDATE Employee SET Experience = 11 WHERE EmpID = 'E014';
UPDATE Employee SET Experience = 2 WHERE EmpID = 'E015';
UPDATE Employee SET Experience = 8 WHERE EmpID = 'E016';
UPDATE Employee SET Experience = 6 WHERE EmpID = 'E017';
UPDATE Employee SET Experience = 3 WHERE EmpID = 'E018';
UPDATE Employee SET Experience = 2 WHERE EmpID = 'E019';
UPDATE Employee SET Experience = 4 WHERE EmpID = 'E020';

SELECT * FROM Employee;


--DROP_COLUMN
ALTER TABLE Patients DROP COLUMN Lname;

--CHANGE_DATA_TYPE_COLUMN
ALTER TABLE Employee ALTER COLUMN Eexperience varchar(10);

--SQL_VIEW (Creating a view for patients in WardNo 'W03')
CREATE VIEW PatientDetails AS SELECT PatID, Fname, Gender, Address, PhoneNo, WardNo FROM Patients WHERE WardNo = 'W03';
SELECT *FROM PatientDetails;
DROP VIEW PatientDetails;

--Sub_Query
SELECT *FROM Employee WHERE (EmpID IN (SELECT EmpID FROM Receptionist )) AND Experience > '2';
SELECT *FROM Employee WHERE (EmpID IN (SELECT EmpID FROM Doctor)) AND (Salary BETWEEN 50000 AND 60000) AND Experience > '5';

--Joining_Table

-- Selecting Patient ID, First Name, and Ward Name 
SELECT Patients.PatID, Patients.Fname, Ward.WardName 
FROM Patients 
INNER JOIN Ward 
ON Patients.WardNo = Ward.WardNo;

-- Selecting Patient Who get Treatment
 SELECT Patients.PatID,Patients.Fname,Treatment.Description
 FROM Patients
 RIGHT JOIN Treatment
 ON Patients.PatID = Treatment.PatID
 ORDER BY Patients.PatID;

-- Selecting Patients who received Treatment and have Invoices
 SELECT Patients.PatID,Patients.Fname,Treatment.Description,Invoice.InvoiceNo
 FROM (
 (Treatment LEFT JOIN Patients ON  Patients.PatID = Treatment.PatID)
 LEFT JOIN Invoice ON Patients.PatID = Invoice.PatID);

 --To get all details Invoice and Payment
 SELECT Invoice.InvoiceNo, Patients.Fname, Invoice.Date AS 'InvoiseDate', Payment.PaymentDate, Invoice.TotalAmount, Payment.Method
 FROM (
 (Invoice FULL OUTER JOIN Payment ON Invoice.InvoiceNo = Payment.InvoiceNo)
 INNER JOIN Patients ON Patients.PatID = Invoice.PatID);

 --Stored_Procedures

--To find which patients are not discharged 
 CREATE PROCEDURE Patients_Discharde_Date
 AS
 BEGIN
   SELECT*
   FROM Patients
   WHERE DischargeDate is null;
   END;

EXEC Patients_Discharde_Date;
DROP PROCEDURE Patients_Discharde_Date;

--To find Count of male patients in Colombo 
CREATE PROCEDURE Count_Patient @Address VARCHAR (50), @Gender VARCHAR (10)
AS
BEGIN
	SELECT COUNT(*) AS 'Count'
	FROM Patients
	WHERE Address = @Address AND Gender = @Gender
	END;

EXEC Count_Patient @Address = 'Colombo',@Gender = 'Male';
DROP PROCEDURE Count_Patient;

--Function

--To display total salary
CREATE FUNCTION Total_Salary()
RETURNS float
AS 
BEGIN
RETURN (SELECT SUM(Salary) AS 'Total' FROM Employee)
END;

SELECT dbo.Total_Salary();
DROP FUNCTION Total_Salary;

--Trigger Backup insert data
CREATE TABLE EmployeeBackupInsert (
    EmpID VARCHAR(10) PRIMARY KEY,
    Fname VARCHAR(50) NOT NULL,
    Lname VARCHAR(50),
    Gender VARCHAR(10) NOT NULL,
    DOB DATE CHECK (DOB<='2000-01-31'),
    Address VARCHAR(50),
    PhoneNo VARCHAR(10),
    Email VARCHAR(100),
    Salary DECIMAL(10, 2)
); 

CREATE TRIGGER Backup_Insert
ON Employee
AFTER INSERT
AS
BEGIN
    INSERT INTO EmployeeBackupInsert (EmpID, Fname, Lname, Gender, DOB, Address, PhoneNo, Email, Salary)
    SELECT EmpID, Fname, Lname, Gender, DOB, Address, PhoneNo, Email, Salary
    FROM INSERTED;
END;

INSERT INTO Employee (EmpID, Fname, Lname, Gender, DOB, Address, PhoneNo, Email, Salary)
VALUES ('E021', 'Jhone', 'Kasturi', 'Male', '1995-12-15', 'Kurunagala', '0764265134', 'JhoneKasturi@email.com', 55000.00);

SELECT * FROM EmployeeBackupInsert;

--Trigger Backup Delete data
CREATE TABLE NurseBackupDelete (
    EmpID VARCHAR(10) PRIMARY KEY,
    Shift VARCHAR(50),
    CertificateLevel VARCHAR(50),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

CREATE TRIGGER Backup_Delete
ON Nurse
AFTER DELETE
AS
BEGIN
    INSERT INTO NurseBackupDelete (EmpID, Shift, CertificateLevel)
    SELECT EmpID, Shift, CertificateLevel
    FROM DELETED;
END;

INSERT INTO Nurse VALUES
    ('E021', 'Night', 'Certified Nurse');

DELETE FROM Nurse WHERE EmpID = 'E021'

SELECT * FROM NurseBackupDelete;

DROP DATABASE Amaa_Hospital;
